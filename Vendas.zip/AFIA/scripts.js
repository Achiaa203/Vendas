// Sidebar navigation hover state management
const sidebarItems = document.querySelectorAll('.sidebar nav ul li');

// Add event listeners for hover and active states
sidebarItems.forEach((item) => {
    item.addEventListener('mouseover', () => {
        item.style.backgroundColor = 'black';
        item.style.color = 'white';
        item.style.borderRadius = '6px';
    });

    item.addEventListener('mouseout', () => {
        item.style.backgroundColor = '';
        item.style.color = '';
        item.style.borderRadius = '';
    });

    item.addEventListener('click', () => {
        sidebarItems.forEach((el) => el.classList.remove('active'));
        item.classList.add('active');
    });
});

// Tab functionality
const tabs = document.querySelectorAll('.tabs .tab');
const contentSections = document.querySelectorAll('.content-section');

tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => {
        // Reset active state for tabs
        tabs.forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');

        // Show corresponding content section
        contentSections.forEach((section) => {
            section.style.display = 'none';
        });
        contentSections[index].style.display = 'block';
    });
    const tabs = document.querySelectorAll('.tabs .tab');

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active')); // Remove 'active' from all tabs
        tab.classList.add('active'); // Add 'active' to clicked tab
    });
});

});


// Default tab and section display
if (tabs.length > 0 && contentSections.length > 0) {
    tabs[0].classList.add('active');
    contentSections[0].style.display = 'block';
}
